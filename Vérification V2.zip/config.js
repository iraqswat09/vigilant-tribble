module.exports = {
  bot: {
    owners: ["" , ""],// owners id
    botID: "",// bot id
    GuildId: "", // Your Server Id
    ClientId: "", // Clietn Id
    serverinvte: "", // Server invite url
    clientSECRET: "", // Client Secret
    callbackURL: "", // Call Back Url
    inviteBotUrl: "",
    TOKEN: (process.env.token) // Bot Token
  },
  website: {
    PORT: "3004",//website port
  }
}